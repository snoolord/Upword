export const SHOW_LIST = "SHOW_LIST";
export const HIDE_LIST = "HIDE_LIST";

export const showList = () => ({
  type: SHOW_LIST
});

export const hideList = () => ({
  type: HIDE_LIST
});
